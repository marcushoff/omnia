Please note that the MIB files must be compiled in the order listed in the "MIBsList.txt".

The MIBs that have the comment "for reference only" are not supported, but their definitions may be required by other MIBs.
